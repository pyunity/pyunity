from .tests import test1
test1.main()