class PyUnityException(Exception):
    pass

class ComponentException(PyUnityException):
    pass

class GameObjectException(PyUnityException):
    pass