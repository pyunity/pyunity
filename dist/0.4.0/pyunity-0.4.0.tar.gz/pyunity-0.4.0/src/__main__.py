from . import examples
examples.show()
