from ..vector3 import Vector3

gravity = Vector3(0, 0, -9.81)