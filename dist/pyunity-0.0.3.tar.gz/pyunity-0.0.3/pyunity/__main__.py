from .examples import example1
example1.main()