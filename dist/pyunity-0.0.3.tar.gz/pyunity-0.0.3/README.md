# PyUnity
## Version 0.0.3 (in development)

A Python implementation of the Unity Engine, that can be used with other Python modules, and supports different types of windowing. Still in development.