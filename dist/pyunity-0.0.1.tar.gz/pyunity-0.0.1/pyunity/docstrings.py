classes = """
    Description
    
    Parameters
    ----------
    param : type
        param description
    
    Raises
    ------
    Exception
        Reason

    Attributes
    ----------
    attr : type
        attr description
    
    """

methods = """
    Description

    Parameters
    ----------
    param : type
        param description
    
    Raises
    ------
    Exception
        Reason